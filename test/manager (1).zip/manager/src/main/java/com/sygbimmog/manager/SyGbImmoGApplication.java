package com.sygbimmog.manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyGbImmoGApplication {

	public static void main(String[] args) {
		SpringApplication.run(SyGbImmoGApplication.class, args);
	}

}
